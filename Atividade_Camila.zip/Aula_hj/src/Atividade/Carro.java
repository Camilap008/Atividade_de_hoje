package Atividade;

public class Carro {
	
	private String modelo;
	private int ano;
	private int torque;
	
	public String getModelo() {
		return modelo;
	}
	
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	public int getAno() {
		return ano;
	}
	
	public void setAno(int ano) {
		this.ano = ano;
	}
	
	public int getTorque() {
		return torque;
	}
	
	public void setTorque(int torque) {
		this.torque = torque;
	}
	
}

