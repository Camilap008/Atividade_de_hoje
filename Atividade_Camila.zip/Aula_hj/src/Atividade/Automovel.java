package Atividade;

import java.util.Scanner;

public class Automovel {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		Carro automovel = new Carro();
		
		System.out.print("Digite o modelo do seu carro: ");
		String modelo = ler.nextLine();
		System.out.print("Digite o ano do seu carro: ");
		int ano = ler.nextInt();
		System.out.print("Digite o torque do seu carro: ");
		int torque = ler.nextInt();
		
		automovel.setModelo(modelo);
		automovel.setAno(ano);
		automovel.setTorque(torque);
		
		System.out.println("\n O modelo do seu carro é: " + automovel.getModelo());
		System.out.println("O ano do seu carro é: " + automovel.getAno());
		System.out.println("O torque do seu carro é: " + automovel.getTorque());
	}
}


